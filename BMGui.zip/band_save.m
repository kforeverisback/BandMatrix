clc
clear
n=100;k=3;r=2;  
A=zeros(n,n);
for i=1:n
    A(i,i)=1;
end
for i=1:(n)
    for j=1:k
      A(i,i+j)=2;
    end
end
for i=1:(n)
    for j=1:r
      A(i+j,i)=3;
    end
end    
A=A(1:n,1:n);
dlmwrite('BM_100_3_2.txt', A, 'delimiter', ',', 'precision', 6);
syms i
NonZero=symsum(r+k-i,i,0,r-1)+symsum(r+k-i,i,0,k-1)+(n-k-r)*(k+r+1);
Zero=n^2-NonZero
total=n^2
Non_Zero_Percent=100*vpa((NonZero)/n^2)
MATLAB_ZEROS=sum(A(:)==0)
MATLAB_NON_ZEROS=sum(A(:)~=0)
spy(A)
