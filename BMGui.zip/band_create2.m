function [ A, total_non_zero, Non_Zero_Percent ] = band_create2( n,k,r,randomize_values, write_parameters, output_file )

%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%n=20;k=4;r=1;
display(sprintf('Create Matrix with parameters n=%d,k=%d,r=%d', n, k, r));
A=zeros(n,n);

if(islogical(randomize_values) && randomize_values)
%% Randomized values
    for i=1:n
        A(i,i)=int32(rand()*1000);
    end
    for i=1:(n)
        for j=1:k
          A(i,i+j)=int32(rand()*1000);
        end
    end
    for i=1:(n)
        for j=1:r
          A(i+j,i)=int32(rand()*1000);
        end
    end

else
%% Fixed Values
    for i=1:n
        A(i,i)=1;
    end
    for i=1:(n)
        for j=1:k
          A(i,i+j)=2;
        end
    end
    for i=1:(n)
        for j=1:r
          A(i+j,i)=3;
        end
    end
end

A=A(1:n,1:n);

if(exist('output_file', 'var'))
    if(~isempty(output_file))
        %% Delete existing file
       if(exist(output_file,'file'))
           delete(output_file);
       end
        %% Write values
        if(islogical(write_parameters) && write_parameters)
            dlmwrite(output_file,[k r],'delimiter', ',', 'precision', 6);
        end
        dlmwrite(output_file, A, 'delimiter', ',', 'precision', 6, '-append');
        display(strcat('File Created: ', output_file))
    end
end
syms i
total_non_zero=symsum(r+k-i,i,0,r-1)+symsum(r+k-i,i,0,k-1)+(n-k-r)*(k+r+1);
%Zero=n^2-NonZero
Non_Zero_Percent=100*vpa((total_non_zero)/n^2);
display(sprintf('Total Non-zero Memory Elements: %d\nSize in KB(4 Byte/MemElem):%.2f KB', total_non_zero, total_non_zero * 4/1024));
display(sprintf('Location representation Size in KB(4 Byte/MemElem):%.2f KB', total_non_zero *3* 4/1024));
display(' ');
end
